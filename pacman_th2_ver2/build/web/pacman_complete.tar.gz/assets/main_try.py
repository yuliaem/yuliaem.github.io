import pygame
import random
import sys
import threading
import asyncio

# ⚠️ Укажи свой актуальный Google Apps Script Web App URL:
SCRIPT_URL = "https://script.google.com/macros/s/AKfycby2BG5KVSoEd-HzY19OcBkfDlUiTcpGtuad5qUlVE6OaA3oO0pycbNjYe9JzE5JDsWv/exec"
IS_WEB = (sys.platform == "emscripten")

# --------- Google Sheets Leaderboard ---------
class GoogleLeaderboard:
    def __init__(self, script_url):
        self.script_url = script_url

    async def send_score(self, name, email, score):
        if IS_WEB:
            try: 
                from js import eval as js_eval
                snippet = f'''
                    fetch(
                        "{self.script_url}", 
                        {{
                            method: "POST",
                            headers: {{"Content-Type": "application/json"}},
                            body: JSON.stringify({{"name": "{name}", "email": "{email}", "score": {score} }})
                        }}
                    )
                    '''
                                
                resp = js_eval(snippet)
            
            except Exception as e:
                print(f"Error: {e}")  # Исправлено: добавлена f-строка
                from js import console
                console.log("fail")
                console.log(str(e))                                
        else:
            import requests
            try:
                data = {"name": name, "email": email, "score": score}
                res = requests.post(self.script_url, json=data)
                if res.status_code == 200:
                    print("✅ Score submitted successfully!")
                else:
                    print(f"⚠️ Error: {res.status_code}")
            except Exception as e:
                print(f"❌ Failed to send score: {e}")

    async def get_leaderboard(self):
        if IS_WEB:
            try:
                from js import eval as js_eval
                snippet = f'''  # Исправлено: убрано дублирование snippet =
                        fetch(
                        "{self.script_url}"
                        )
                        '''
                resp = js_eval(snippet)
                # В веб-версии нужно добавить обработку ответа
                # data = await resp.json()
                # header, *rows = data
                # rows.sort(key=lambda r: int(r[3]), reverse=True)
                # return rows[:10]
                return []  # Временно возвращаем пустой список
            except Exception as e:
                print(f"Error: {e}")  # Исправлено: добавлена f-строка
                from js import console
                console.log("fail")
                console.log(str(e))
                return []
        else:
            import requests
            try:
                res = requests.get(self.script_url)
                if res.status_code == 200:
                    raw = res.json()
                    header, *rows = raw
                    sorted_rows = sorted(rows, key=lambda x: int(x[3]), reverse=True)
                    return sorted_rows[:10]
                else:
                    print(f"⚠️ Error: {res.status_code}")
                    return []
            except Exception as e:
                print(f"❌ Failed to fetch leaderboard: {e}")
                return []


# --------- Текстовое поле ---------
class InputBox:
    def __init__(self, x, y, w, h, text=""):
        self.rect = pygame.Rect(x, y, w, h)
        self.color_inactive = pygame.Color("gray")
        self.color_active = pygame.Color("dodgerblue2")
        self.color = self.color_inactive
        self.text = text
        self.font = pygame.font.SysFont("Arial", 20)
        self.txt_surface = self.font.render(text, True, (255, 255, 255))
        self.active = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = not self.active
            else:
                self.active = False
            self.color = self.color_active if self.active else self.color_inactive

        if event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                return self.text
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            else:
                self.text += event.unicode
            self.txt_surface = self.font.render(self.text, True, (255, 255, 255))
        return None

    def draw(self, screen):
        screen.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))
        pygame.draw.rect(screen, self.color, self.rect, 2)


# --------- Окно ввода имени и почты ---------
class InputForm:
    def __init__(self, surface):
        self.surface = surface
        self.visible = False
        self.font = pygame.font.SysFont("Arial", 22, bold=True)
        self.label_font = pygame.font.SysFont("Arial", 22, bold=True)
        self.rect = pygame.Rect(80, 200, 320, 200)
        self.glb = GoogleLeaderboard(SCRIPT_URL)

        # Позиционирование: метки слева, поля ввода справа
        label_width = 80  # Ширина области для меток
        field_width = 180  # Ширина полей ввода
        start_x = self.rect.x + 20
        start_y = self.rect.y + 50
        
        # Метки и поля ввода на одной линии
        self.name_label_rect = pygame.Rect(start_x, start_y, label_width, 32)
        self.name_box = InputBox(start_x + label_width, start_y, field_width, 32)
        
        self.email_label_rect = pygame.Rect(start_x, start_y + 50, label_width, 32)
        self.email_box = InputBox(start_x + label_width, start_y + 50, field_width, 32)

        self.enter_btn = pygame.Rect(self.rect.x + 100, self.rect.y + 150, 120, 32)

    def open(self):
        self.visible = True
        self.name_box.text = ""
        self.email_box.text = ""
        self.name_box.txt_surface = self.name_box.font.render("", True, (255, 255, 255))
        self.email_box.txt_surface = self.email_box.font.render("", True, (255, 255, 255))

    def handle_event(self, event):
        if not self.visible:
            return

        self.name_box.handle_event(event)
        self.email_box.handle_event(event)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.enter_btn.collidepoint(event.pos):
                print("👉 Submitted:", self.name_box.text, self.email_box.text)
                player_score = 1000
                asyncio.create_task(
                        self.glb.send_score(self.name_box.text, self.email_box.text, player_score)
                    )
                self.visible = False

    def draw(self):
        if not self.visible:
            return

        pygame.draw.rect(self.surface, (30, 30, 30), self.rect, border_radius=10)
        pygame.draw.rect(self.surface, (200, 200, 200), self.rect, 2, border_radius=10)

        # Отрисовка меток слева от полей ввода
        name_lbl = self.label_font.render("Name:", True, (255, 255, 255))
        email_lbl = self.label_font.render("Email:", True, (255, 255, 255))
        
        # Выравнивание меток по правому краю их области
        self.surface.blit(name_lbl, (self.name_label_rect.right - name_lbl.get_width() - 5, 
                                   self.name_label_rect.y + 8))
        self.surface.blit(email_lbl, (self.email_label_rect.right - email_lbl.get_width() - 5, 
                                    self.email_label_rect.y + 8))

        # Отрисовка полей ввода
        self.name_box.draw(self.surface)
        self.email_box.draw(self.surface)

        # Кнопка Enter
        pygame.draw.rect(self.surface, (50, 150, 255), self.enter_btn, border_radius=6)
        enter_lbl = self.font.render("Enter", True, (255, 255, 255))
        self.surface.blit(
            enter_lbl,
            (self.enter_btn.centerx - enter_lbl.get_width() // 2,
             self.enter_btn.centery - enter_lbl.get_height() // 2)
        )


# --------- Leaderboard UI ---------
class LeaderboardView:
    def __init__(self, leaderboard, surface, close_img):
        self.leaderboard = leaderboard
        self.surface = surface
        self.font = pygame.font.SysFont("Courier New", 20, bold=True)
        self.visible = False
        self.rect = pygame.Rect(60, 60, 360, 480)
        self.bg_color = (30, 30, 30)
        self.text_color = (255, 255, 255)
        self.score_color = (255, 236, 67)
        self.close_img = close_img
        self.close_rect = self.close_img.get_rect(topright=(self.rect.right - 10, self.rect.top + 10))
        self.entries = []
        self.loading = False

    def open(self):
        self.entries = []
        self.loading = True
        self.visible = True
        asyncio.create_task(self._fetch_data())

    async def _fetch_data(self):
        data = await self.leaderboard.get_leaderboard()
        self.entries = data
        self.loading = False

    def draw(self):
        if not self.visible:
            return
            
        pygame.draw.rect(self.surface, self.bg_color, self.rect, border_radius=12)
        pygame.draw.rect(self.surface, (200, 200, 200), self.rect, width=2, border_radius=12)

        title = self.font.render("HIGH SCORE", True, self.text_color)
        self.surface.blit(title, (self.rect.centerx - title.get_width() // 2, self.rect.top + 20))
        self.surface.blit(self.close_img, self.close_rect)

        y = self.rect.top + 70
        row_height = 40

        if self.loading:
            loading_text = self.font.render("Loading...", True, (180, 180, 180))
            self.surface.blit(loading_text, (self.rect.centerx - loading_text.get_width() // 2, y))
        else:
            for i, row in enumerate(self.entries):
                if len(row) >= 4:  # Проверка на наличие всех элементов
                    name, score = row[1], row[3]
                    text = self.font.render(f"{i+1:>2} {name:<12} {score:>5}", True, self.score_color)
                    self.surface.blit(text, (self.rect.left + 20, y))
                    y += row_height

    def handle_click(self, pos):
        if self.visible and self.close_rect.collidepoint(pos):
            self.visible = False


# --------- Main Game Loop ---------
async def main():
    pygame.init()
    W, H = 480, 720
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Game with Google Sheets Leaderboard")
    clock = pygame.time.Clock()

    font = pygame.font.SysFont("Arial", 18, bold=True)

    # кнопка Leaderboard
    leaderboard_btn = pygame.Rect(W - 300, 20, 120, 40)

    # кнопка Send
    send_btn = pygame.Rect(W - 160, 20, 120, 40)

    # Setup leaderboard logic
    close_img = pygame.Surface((32, 32), pygame.SRCALPHA)
    pygame.draw.circle(close_img, (200, 50, 50), (16, 16), 16)
    pygame.draw.line(close_img, (255, 255, 255), (10, 10), (22, 22), 3)
    pygame.draw.line(close_img, (255, 255, 255), (22, 10), (10, 22), 3)
    
    # Создаем экземпляры после инициализации pygame
    glb = GoogleLeaderboard(SCRIPT_URL)
    lb_view = LeaderboardView(glb, screen, close_img)  # Исправлено: передаем правильные параметры
    input_form = InputForm(screen)

    running = True
    while running:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
            elif ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                running = False

            if input_form.visible:
                input_form.handle_event(ev)
            elif lb_view.visible:
                if ev.type == pygame.MOUSEBUTTONDOWN:
                    lb_view.handle_click(ev.pos)
            else:
                if ev.type == pygame.MOUSEBUTTONDOWN:
                    if leaderboard_btn.collidepoint(ev.pos):
                        lb_view.open()
                    elif send_btn.collidepoint(ev.pos):
                        input_form.open()

        screen.fill((25, 25, 25))
        pygame.draw.circle(screen, (100, 255, 100), (240, 360), 60)

        if not (lb_view.visible or input_form.visible):
            # Кнопка Leaderboard
            pygame.draw.rect(screen, (50, 150, 255), leaderboard_btn, border_radius=6)
            lbl1 = font.render("Leaderboard", True, (255, 255, 255))
            screen.blit(lbl1, (leaderboard_btn.centerx - lbl1.get_width() // 2,
                               leaderboard_btn.centery - lbl1.get_height() // 2))

            # Кнопка Send
            pygame.draw.rect(screen, (0, 200, 0), send_btn, border_radius=6)
            lbl2 = font.render("Send", True, (255, 255, 255))
            screen.blit(lbl2, (send_btn.centerx - lbl2.get_width() // 2,
                               send_btn.centery - lbl2.get_height() // 2))

        if lb_view.visible:
            lb_view.draw()

        if input_form.visible:
            input_form.draw()

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())