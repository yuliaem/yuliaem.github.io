import pygame
import requests
import random
import threading

# --- Экран и сетка ---
TILEWIDTH  = 16
TILEHEIGHT = 16
NROWS = 36
NCOLS = 28
FRAMESIZE = 200
SCREENWIDTH  = NCOLS * TILEWIDTH
SCREENHEIGHT = NROWS * TILEHEIGHT
SCREENSIZE   = (SCREENWIDTH, SCREENHEIGHT + FRAMESIZE)

# ⚠️ Укажи свой актуальный Google Apps Script Web App URL:
SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzm6sken94Tc5ZBgbco9_s1yjin345OcEV6RJMXdZGZRg9lbJnUqauzznCWfEwXq_SG/exec"

# --------- Google Sheets Leaderboard ---------
class GoogleLeaderboard:
    def __init__(self, script_url):
        self.script_url = script_url

    def send_score(self, name, email, score):
        try:
            data = {"name": name, "email": email, "score": score}
            res = requests.post(self.script_url, json=data)
            if res.status_code == 200:
                print("✅ Score submitted successfully!")
            else:
                print(f"⚠️ Error: {res.status_code}")
        except Exception as e:
            print(f"❌ Failed to send score: {e}")

    def get_leaderboard(self):
        try:
            res = requests.get(self.script_url)
            if res.status_code == 200:
                raw = res.json()  # [['Timestamp', 'Name', 'Email', 'Score'], [...]]
                header, *rows = raw
                sorted_rows = sorted(rows, key=lambda x: int(x[3]), reverse=True)
                return sorted_rows[:10]
            else:
                print(f"⚠️ Error: {res.status_code}")
                return []
        except Exception as e:
            print(f"❌ Failed to fetch leaderboard: {e}")
            return []

# --------- Leaderboard UI ---------
class LeaderboardView:
    def __init__(self, leaderboard, surface, close_img):
        self.leaderboard = leaderboard
        self.surface = surface
        self.font = pygame.font.SysFont("Courier New", 24, bold=True)  # чуть крупнее
        self.visible = False

        # Увеличиваем размеры окна
        w = int(SCREENWIDTH * 0.8)
        h = int(SCREENHEIGHT * 0.95)
        self.rect = pygame.Rect(
            (SCREENWIDTH - w) // 2,
            (SCREENHEIGHT - h) // 2,
            w,
            h
        )

        self.bg_color = (30, 30, 30)
        self.text_color = (255, 255, 255)
        self.score_color = (255, 236, 67)
        self.close_img = close_img
        self.close_rect = self.close_img.get_rect(topright=(self.rect.right - 15, self.rect.top + 15))
        self.entries = []
        self.loading = False

    def open(self):
        self.entries = []
        self.loading = True
        self.visible = True
        threading.Thread(target=self._fetch_data, daemon=True).start()

    def _fetch_data(self):
        data = self.leaderboard.get_leaderboard()
        self.entries = data
        self.loading = False

    def draw(self):
        pygame.draw.rect(self.surface, self.bg_color, self.rect, border_radius=12)
        pygame.draw.rect(self.surface, (200, 200, 200), self.rect, width=2, border_radius=12)

        title = self.font.render("HIGH SCORE", True, self.text_color)
        self.surface.blit(title, (self.rect.centerx - title.get_width() // 2, self.rect.top + 25))
        self.surface.blit(self.close_img, self.close_rect)

        y = self.rect.top + 80
        row_height = 45  # больше вертикальный шаг

        if self.loading:
            loading_text = self.font.render("Loading...", True, (180, 180, 180))
            self.surface.blit(loading_text, (self.rect.centerx - loading_text.get_width() // 2, y))
        else:
            for i, row in enumerate(self.entries):
                name, email, score = row[1], row[2], row[3]
                text = self.font.render(f"{i+1:>2}. {name:<12} {score:>5}", True, self.score_color)
                self.surface.blit(text, (self.rect.left + 30, y))
                y += row_height

    def handle_click(self, pos):
        if self.visible and self.close_rect.collidepoint(pos):
            self.visible = False

# --------- Main Game Loop ---------
def main():
    pygame.init()
    screen = pygame.display.set_mode(SCREENSIZE)
    pygame.display.set_caption("Game with Google Sheets Leaderboard")
    clock = pygame.time.Clock()

    # Load button images or fallback
    leaderboard_btn_img = pygame.image.load("btn_leaderboard.png").convert_alpha()
    
    close_btn_img = pygame.image.load("btn_close.png").convert_alpha()
   

    # --- Кнопка вверху между SCORE и LEVEL ---
    btn_y = 5 * TILEHEIGHT // 4   # тот же уровень, где SCORE/LEVEL
    btn_x = SCREENWIDTH // 2 - leaderboard_btn_img.get_width() // 2
    leaderboard_btn_rect = leaderboard_btn_img.get_rect(topleft=(btn_x, btn_y))

    # Setup leaderboard logic
    glb = GoogleLeaderboard(SCRIPT_URL)
    lb_view = LeaderboardView(glb, screen, close_btn_img)

    running = True
    while running:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False

            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if not lb_view.visible and leaderboard_btn_rect.collidepoint(ev.pos):
                    lb_view.open()
                elif lb_view.visible:
                    lb_view.handle_click(ev.pos)

        # --- Main Game ---
        screen.fill((25, 25, 25))

        # тут твоя игровая отрисовка (SCORE, LEVEL, READY, и т.д.)

        # кнопка лидерборда
        if not lb_view.visible:
            screen.blit(leaderboard_btn_img, leaderboard_btn_rect)

        if lb_view.visible:
            lb_view.draw()

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    main()