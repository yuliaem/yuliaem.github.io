import pygame
import json
import os
import random
import time

# ---------------- ДАННЫЕ ----------------
class Leaderboard:
    def __init__(self, path="leaderboard.json", max_keep=1000):
        self.path = path
        self.max_keep = max_keep
        self.entries = []
        self.load()

    def load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    self.entries = json.load(f)
            except Exception:
                self.entries = []
        else:
            self.entries = []

    def save(self):
        self.entries = sorted(self.entries, key=lambda e: (-e["score"], e["ts"]))[:self.max_keep]
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.entries, f, ensure_ascii=False, indent=2)

    def add_score(self, name: str, score: int):
        self.entries.append({"name": name[:12], "score": int(score), "ts": int(time.time())})
        self.save()

    def top(self, n=10):
        return sorted(self.entries, key=lambda e: (-e["score"], e["ts"]))[:n]

    def clear(self):
        self.entries = []
        self.save()

# ---------------- UI ----------------
class LeaderboardView:
    def __init__(self, lb: Leaderboard, surface, close_btn_img):
        self.lb = lb
        self.surface = surface
        self.font = pygame.font.SysFont("Courier New", 20, bold=True)
        self.visible = False
        self.rect = pygame.Rect(60, 60, 360, 480)
        self.bg_color = (30, 30, 30)
        self.text_color = (255, 255, 255)
        self.score_color = (255, 236, 67)
        self.close_img = close_btn_img
        self.close_rect = self.close_img.get_rect(topright=(self.rect.right - 10, self.rect.top + 10))

    def draw(self):
        pygame.draw.rect(self.surface, self.bg_color, self.rect, border_radius=12)
        pygame.draw.rect(self.surface, (200, 200, 200), self.rect, width=2, border_radius=12)

        title = self.font.render("HIGH SCORE", True, self.text_color)
        self.surface.blit(title, (self.rect.centerx - title.get_width() // 2, self.rect.top + 20))

        self.surface.blit(self.close_img, self.close_rect)

        top_scores = self.lb.top(10)
        y = self.rect.top + 70
        row_height = 40

        for i, entry in enumerate(top_scores, 1):
            name = entry["name"]
            score = entry["score"]
            line = f"{i:>2}  {name:<12}  {score:>5}"
            text = self.font.render(line, True, self.score_color)
            self.surface.blit(text, (self.rect.left + 20, y))
            y += row_height

    def handle_click(self, pos):
        if self.visible and self.close_rect.collidepoint(pos):
            self.visible = False

# ---------------- MAIN GAME + UI ----------------
def main():
    pygame.init()
    W, H = 480, 720
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("Game with Leaderboard")

    clock = pygame.time.Clock()

    # Load images
    try:
        leaderboard_btn_img = pygame.image.load("btn_leaderboard.png").convert_alpha()
    except:
        leaderboard_btn_img = pygame.Surface((120, 40))
        leaderboard_btn_img.fill((50, 150, 255))
        pygame.draw.rect(leaderboard_btn_img, (255, 255, 255), leaderboard_btn_img.get_rect(), 2)
        font = pygame.font.SysFont("Arial", 18, bold=True)
        leaderboard_btn_img.blit(font.render("Leaderboard", True, (255, 255, 255)), (10, 10))

    try:
        close_btn_img = pygame.image.load("btn_close.png").convert_alpha()
    except:
        close_btn_img = pygame.Surface((32, 32), pygame.SRCALPHA)
        pygame.draw.circle(close_btn_img, (200, 50, 50), (16, 16), 16)
        pygame.draw.line(close_btn_img, (255, 255, 255), (10,10), (22,22), 3)
        pygame.draw.line(close_btn_img, (255, 255, 255), (22,10), (10,22), 3)

    leaderboard_btn_rect = leaderboard_btn_img.get_rect(topleft=(W - 140, 20))

    # Init leaderboard
    lb = Leaderboard()
    if not lb.entries:
        for name, score in [("Masha",1200),("Alex",950),("Polina",1380),("Nika",720),
                            ("Dima",1330),("Egor",990),("Lena",760),("You",1800)]:
            lb.add_score(name, score)

    lb_view = LeaderboardView(lb, screen, close_btn_img)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_a:
                    lb.add_score(random.choice(["You", "Bot", "Alex"]), random.randint(100, 2000))
                elif event.key == pygame.K_c:
                    lb.clear()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if not lb_view.visible and leaderboard_btn_rect.collidepoint(event.pos):
                    lb_view.visible = True
                elif lb_view.visible:
                    lb_view.handle_click(event.pos)

        # --- Игровой экран (фон и элементы игры) ---
        screen.fill((25, 25, 25))
        pygame.draw.circle(screen, (100, 255, 100), (240, 360), 60)  # шарик - "игра"

        # --- Кнопка Leaderboard ---
        if not lb_view.visible:
            screen.blit(leaderboard_btn_img, leaderboard_btn_rect)

        # --- Leaderboard overlay ---
        if lb_view.visible:
            lb_view.draw()

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    main()